load sma.dat;
figure;
plot(sma);
legend('Input', 'Output');
title('Moving average output for N = 4');
xlabel('half hour');
ylabel('Number of customers');
xlabel('Half hour');
grid;